#ifndef __HW_DISPLAY_H__
#define __HW_DISPLAY_H__
void display(char *);
#endif
